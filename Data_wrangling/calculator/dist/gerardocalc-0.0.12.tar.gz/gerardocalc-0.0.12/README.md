# Calculator

This is a calculator done for the Turing college sprint 1

